import React from "react";

const WorkExperienceCard = () => {
  return (
    <div>
      <div className="main col-md">
        <div className="">
          <div className="card-body ">
            <h2 className="card-title  ">Work Experience</h2>
            <div className="work-box">
              <div className="work-box-styl">
                <h5 className="fw-bold">
                  Risk Analyst (Investment Advisor Assistant) / April 2021 -
                  September 2022
                </h5>
                <span>CIBC Wood Gundy,Calgary, Alberta</span>
                <ul>
                  <li>
                    Achieved a 5% increase in a $650m portfolio for 4 advisors
                    by analyzing industry and product trends.
                  </li>
                  <li>
                    Provided regular updates and reports using various tools and
                    performance data, resulting in a 20% increase in
                    transparency and informed decision-making.
                  </li>
                  <li>
                    Supported documentation management for various purposes,
                    ensuring a 15% improvement in the accessibility and
                    organization of critical project documents.
                  </li>
                  <li>
                    Led up to 10 colleagues, ensuring the timely delivery of
                    projects with a success rate exceeding 95%.
                  </li>
                </ul>
              </div>
              <div className="work-box-styl">
                <h5 className="fw-bold">
                  Business Manager / January 2018 - December 2019
                </h5>
                <span>LS Mannison Trading Ltd, Accra, Ghana</span>
                <ul>
                  <li>
                    Successfully drove communication and engagement on strategic
                    projects, leading to improved decision-making and the
                    company turning a 40% profit in year two.
                  </li>
                  <li>
                    Collaborated extensively with stakeholders, achieving a 10%
                    improvement in project delivery timeliness and on-time
                    completion rate.
                  </li>
                  <li>
                    Established risk management protocols to identify, assess,
                    and mitigate potential risks, safeguarding organizational
                    objectives and reducing risk incidents by 15%.
                  </li>
                  <li>
                    Saved 10% in annual costs and improved project efficiency
                    through effective schedule management, minimizing delays,
                    overtime, and expenses.
                  </li>
                  <li>
                    Reduced waste and theft by 65% over 2 years through root
                    cause analyses, optimizing processes, and addressing
                    underlying issues to improve profitability
                  </li>
                </ul>
              </div>
              <div className="work-box-styl">
                <h5 className="fw-bold">
                  Project Manager / January 2013 - December 2018
                </h5>
                <span>Pinnacle Investments, Accra, Ghana</span>
                <ul>
                  <li>
                    Led scope development and executed projects, achieving an
                    average annual increase of approximately 12% in operational
                    efficiency and cost savings over 5 years.
                  </li>
                  <li>
                    Identified risks and anticipated issues, leading to a 20%
                    decrease in project disruptions and a 25% increase in
                    proactive issue resolution.
                  </li>
                  <li>
                    Proactively identified and mitigated project risks, reducing
                    disruptions by 30% and resolving issues promptly.
                  </li>
                  <li>
                    Improved project performance by about 15% by developing and
                    improving project controls strategies, plans, and
                    standardized project controls framework.
                  </li>
                </ul>
              </div>
              <div className="work-box-styl">
                <h5 className="fw-bold">
                  Transactions Coordinator / March 2010 – July 2012
                </h5>
                <span>
                  Office of Gas and Electricity Markets (OFGEM), London, United
                  Kingdom
                </span>
                <ul>
                  <li>
                    Supported organizational change management and complex
                    business transformation projects, delivering cost savings of
                    $300m to $600m by 2014
                  </li>
                  <li>
                    Managed contracts totalling approximately $7 million,
                    leveraging data and analytics tools to achieve savings of up
                    to 15% of the contract value.
                  </li>
                  <li>
                    Implemented a standardized cost tracking system, resulting
                    in improved accuracy and timeliness of cost reporting by
                    70%.
                  </li>
                  <li>
                    Led communication and collaboration between data & analytics
                    teams and stakeholders on three strategic projects, reducing
                    delays by 40% and improving stakeholder satisfaction by 25%.
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WorkExperienceCard;

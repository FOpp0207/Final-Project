import React from "react";

const TechnologySummaryCard = () => {
  return (
    <div>
      <div className="col-md mb-5">
        <div className="">
          <div className="card-body">
            <h2 className="card-title">Technology Summary</h2>
            <div className="tech-box">
              <div className="tech-box-styl">
                <h5 className="fw-bold">Knowledge of Agile methodologies</h5>
                <p>
                  Familiarity with Agile principles empowers teams to adapt,
                  collaborate, and deliver value incrementally, enhancing
                  project flexibility and customer satisfaction.
                </p>
              </div>
              <div className="tech-box-styl">
                <h5 className="fw-bold">Scope development</h5>
                <p>
                  Careful and iterative scope development is crucial to defining
                  project boundaries and deliverables accurately, minimizing
                  scope creep and ensuring project success.
                </p>
              </div>
              <div className="tech-box-styl">
                <h5 className="fw-bold">Project Reporting and documentation</h5>
                <p>
                  Regularly updating stakeholders on project milestones,
                  challenges, and progress ensures transparency and informed
                  decision-making.Comprehensive project documentation serves as
                  a valuable knowledge repository, aiding seamless
                  collaboration, troubleshooting, and future enhancements.
                </p>
              </div>
              <div className="tech-box-styl">
                <h5 className="fw-bold">
                  Knowledge of Lean project principles
                </h5>
                <p>
                  Understanding Lean principles optimizes processes, reduces
                  waste, and promotes efficient resource utilization, leading to
                  streamlined project workflows and increased value delivery.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TechnologySummaryCard;

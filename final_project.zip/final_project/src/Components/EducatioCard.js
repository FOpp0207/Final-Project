import React from "react";

const EducatioCard = () => {
  return (
    <div>
      <div className="col-md">
        <div className="">
          <div className="card-body">
            <h2 className="card-title">Education</h2>
            <div className="box">
              <div className="box-styl">
                <h5 className="fw-bold">
                  MS. IT, Management & Organizational Change | Lancaster
                  University September 2006
                </h5>
                <p>
                  This program integrates technology, management strategies, and
                  organizational dynamics, preparing graduates to drive
                  effective digital transformations.
                </p>
              </div>
              <div className="box-styl">
                <h5 className="fw-bold">
                  BSc. Business Administration | Central University College July
                  2003
                </h5>
                <p>
                  A comprehensive program cultivating versatile business acumen
                  and leadership skills for success in diverse corporate
                  environments
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EducatioCard;

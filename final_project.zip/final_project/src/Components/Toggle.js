import React, { useContext } from "react";
import { ThemeContext } from "../Context/ThemeContext";

const Posts = () => {
  const { theme, handleClick } = useContext(ThemeContext);

  // const handleClick=()=>{
  //   console.log("click")
  // }
  return (
    <div>
      <button
        onClick={handleClick}
        className={`btn ${theme === "dark" ? "btn-light" : "btn-dark"}`}
      >
         {theme}
      </button>
    </div>
  );
};

export default Posts;

// import logo from "./logo.svg";
import "./App.css";
import EducatioCard from "./Components/EducatioCard";
import { Header } from "./Components/Header";
import TechnologySummaryCard from "./Components/TechnologySummaryCard";
import WorkExperienceCard from "./Components/WorkExperienceCard";
import Toggle from "./Components/Toggle";
import { useEffect, useState } from "react";
import { ThemeContext, themes } from "./Context/ThemeContext";

function App() {
  const [theme, setTheme] = useState(themes.light);

  const handleClick = () => {
    theme === themes.light ? setTheme(themes.dark) : setTheme(themes.light);
  };
  const body = document.body;
  useEffect(() => {
    switch (theme) {
      case themes.dark:
        body.classList.remove("bg-dark");
        body.classList.remove("text-light");
        body.classList.add("bg-light");
        body.classList.add("text-dark");
        
        break;
      case themes.light:
        body.classList.remove("bg-light");
        body.classList.remove("text-dark");
        body.classList.add("bg-dark");
        body.classList.add("text-light");
        break;
      default:
        body.classList.remove("bg-light");
        body.classList.remove("text-dark");
        body.classList.add("bg-dark");
        body.classList.add("text-light");
    }
  });

  return (
    <div className="App">
      <ThemeContext.Provider value={{ theme, handleClick }}>
        <Header />
        <Toggle theme={theme} />
        <main className="container back">
          <div className="main row mt-3">
            <EducatioCard />
            <WorkExperienceCard />
            <TechnologySummaryCard />
          </div>
        </main>
      </ThemeContext.Provider>
    </div>
  );
}

export default App;
